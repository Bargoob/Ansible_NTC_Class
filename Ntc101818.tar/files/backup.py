from netmiko import ConnectHandler

platform = 'cisco_ios'
host1 = 'csr1'
host2 = 'csr2'
username = 'ntc'
password = 'ntc123'

##Connecting to CSR1
device = ConnectHandler(device_type=platform, ip=host1, username=username, password=password)

#Checking Connection
Host1Conn = device.is_alive()
print Host1Conn



#Running Command to save config
output1 = device.send_command('wr mem')
running1 = device.send_command('sh runn')

print output1

#Opening file for saving
out_file = open('csr1.cfg' , 'w')
out_file.write(running1)
out_file.close()

#CSR1 Disconnect
device.disconnect()
Host1Conn = device.is_alive()
print(Host1Conn)
#
##Connecting to CSR2
device = ConnectHandler(device_type=platform, ip=host2, username=username, password=password)

#Checking Connection
Host2Conn = device.is_alive()
print Host2Conn


#Running Command to save config
output2 = device.send_command('wr mem')
running2 = device.send_command('sh runn')

print output2

#Opening file for saving
out_file = open('csr2.cfg' , 'w')
out_file.write(running2)
out_file.close()


#CSR2 Disconnect
device.disconnect()
Host2Conn = device.is_alive()
print(Host2Conn)
#





	
