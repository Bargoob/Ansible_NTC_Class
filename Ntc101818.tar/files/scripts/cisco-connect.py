from netmiko import ConnectHandler


def ez_cisco(hostname, username, password, show_command):
	platform = "cisco_ios"
	device = ConnectHandler(ip=hostname, username=username, password=password, device_type=platform)

	output = device.send_command(show_command)
	device.disconnect()

	return output

	response = ez_cisco('csr1', 'ntc', 'ntc123', 'show version')

   	print(response)

	print(hostname)
	print(username)
	print(password)
	print(show_command)

ez_cisco('csr1', 'ntc', 'ntc123', 'show version')