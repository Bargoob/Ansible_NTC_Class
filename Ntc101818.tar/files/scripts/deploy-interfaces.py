from netmiko import ConnectHandler

#Create the INTERFACE_MAP
INTERFACE_MAP = {
    "csr1":
        {
            "interface": "GigabitEthernet4",
            "ipaddr": "10.100.12.1",
            "mask": "255.255.255.0",
            "description": "Connect to csr2"
        },
    "csr2":
        {
            "interface": "GigabitEthernet4",
            "ipaddr": "10.100.12.2",
            "mask": "255.255.255.0",
            "description": "Connect to csr1"
        }
  }

#Initiate the connection to csr1 and csr2
csr1 = ConnectHandler(host='csr1', username='ntc', password='ntc123', device_type='cisco_ios')
csr2 = ConnectHandler(host='csr2', username='ntc', password='ntc123', device_type='cisco_ios')

#ommands for configuring an IP address and description on the interface
csr1_interface_command = "interface {}".format(INTERFACE_MAP['csr1']['interface'])
csr1_ipaddr_command = "ip address {} {}".format(INTERFACE_MAP['csr1']['ipaddr'], INTERFACE_MAP["csr1"]["mask"])
csr1_descr_command = "description {}".format(INTERFACE_MAP['csr1']['description'])

#Create a list of the three commands you created in the last Step.
csr1_commands = [csr1_interface_command, csr1_ipaddr_command, csr1_descr_command]

# for csr2:
csr2_interface_command = "interface {}".format(INTERFACE_MAP['csr2']['interface'])
csr2_ipaddr_command = "ip address {} {}".format(INTERFACE_MAP['csr2']['ipaddr'], INTERFACE_MAP["csr2"]["mask"])
csr2_descr_command = "description {}".format(INTERFACE_MAP['csr2']['description'])

#Create a list of the three commands you created in the last Step.
csr2_commands = [csr2_interface_command, csr2_ipaddr_command, csr2_descr_command]

#Deploy the commands to each device 
csr1.send_config_set(csr1_commands)
csr2.send_config_set(csr2_commands)

print(csr1.send_command("ping {}".format(INTERFACE_MAP['csr2']['ipaddr'])))
print(csr2.send_command("ping {}".format(INTERFACE_MAP['csr1']['ipaddr'])))

#Disconnect 
csr1.disconnect()
csr2.disconnect()