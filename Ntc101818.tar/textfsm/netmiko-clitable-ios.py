#! /usr/bin/env python

import json
import clitable
from netmiko import ConnectHandler
from ntc_course import clitable_to_dict

TEMPLATES_DIR = '/etc/ntc/ansible/library/ntc-ansible/ntc-templates/templates'
INDEX_FILE = '/etc/ntc/ansible/library/ntc-ansible/ntc-templates/templates/index'

if __name__ == "__main__":

    platform = 'cisco_ios'
    host = 'csr1'
    command = 'show ip int brief'

    device = ConnectHandler(
                device_type=platform,
                ip=host,
                username='ntc',
                password='ntc123'
                )

    rawtxt = device.send_command(command)

    cli_table = clitable.CliTable(INDEX_FILE, TEMPLATES_DIR)

    attrs = {
        'Command': command,
        'Platform': platform
    }

    cli_table.ParseCmd(rawtxt, attrs)

    structured_data = clitable_to_dict(cli_table)

    print json.dumps(structured_data, indent=4)

